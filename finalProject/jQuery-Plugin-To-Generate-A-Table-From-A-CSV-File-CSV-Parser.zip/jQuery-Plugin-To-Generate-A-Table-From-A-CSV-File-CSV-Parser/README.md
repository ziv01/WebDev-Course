jQuery CSV Parser
=========

For parsing and displaying .CSV files in jQuery

Simple CSV Reader in jQuery. This is a skeleton for making datatables from a csv in jQuery. Easy stuff but I thought I'd store it here for others to use. 