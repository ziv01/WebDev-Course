# Learning HTML Forms - Exercise 01
* create a form
* create a name field.
* create an address field.
* Make these two fields #reqired.
* add <input type="submit">
